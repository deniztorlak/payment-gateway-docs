﻿using System;
using System.Globalization;
using System.Security.Principal;
using System.Web;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.IO;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Text;
using System.Xml;
using System.Security.Cryptography;


public partial class odeme_yap : System.Web.UI.Page
{



    protected void Page_Load(object sender, EventArgs e)
    {


        if (!Page.IsPostBack)
        {
            if (Request.QueryString["kayitId"] != null)
            {
                if (!IsPostBack)
                {

                 }
            }
            else
            {
        
            }
        }
   
    
    }

   


    


    protected void Button1_Click(object sender, EventArgs e)
    {

               try
        {

            string strTerminalID = "10000391";
            string _strTerminalID = "0" + strTerminalID; //Başına 0 eklenerek 9 digite tamamlanmalıdır.
            string strTerminalMerchantID = "3424113 "; //Üye İşyeri Numarası
            string strStoreKey = "12345678"; //3D Secure şifresi
            string strProvisionPassword = "123qweASD"; //TerminalProvUserID şifresi

            string srtsecure3dsecuritylevel = "CUSTOM_PAY";
        string strMode = "PROD";
        string strApiVersion = "v0.01";
        string strTerminalProvUserID = "PROVOOS";
        string strType = "gpdatarequest";
        string strtxnsubtype = "sales";
        string strAmount = "100"; //İşlem Tutarı 1.00 TL için 100 gönderilmeli.

        string strInstallmentCount = ""; //Taksit Sayısı. Custom Pay için burada gönderilmez boş olmalı 
        string strinstallmentamount1 = "110"; // ilk seçimdeki 2 taksitli fiyatı 
        string strinstallmentamount2 = "120"; // ilk seçimdeki 2 taksitli fiyatı 
        string strCurrencyCode = "949";

        string strTerminalUserID = "PROVOOS";
        string strOrderID = KodOlustur(DateTime.Now.ToString());/*Sipar no ;*/  //her işlemde farklı bir değer gönderilmeli

        string strCustomeripaddress = Request.UserHostAddress;/*Request.UserHostAddress;*/ //Kullanıcının IP adresini alır

        // local host ve ip ::1 gelir ise burası devreye girer.
        if (strCustomeripaddress == "::1")
        {
            strCustomeripaddress = "192.1.1.1";
        }
        string strCustomeremailaddress = "emrez@garanti.com.tr"; // müşteri mail adresi için 

        string strSuccessURL = "https://eticaret.garanti.com.tr/destek/postback.aspx";
        string strErrorURL = "https://eticaret.garanti.com.tr/destek/postback.aspx"; 
        string strCompanyName = "CUSTOM PAY "; // Türkçe karakter kullanılmamalı
        string strlang = "tr";
        string strRefreshTime = "5"; 
        string strtimestamp = System.DateTime.Now.ToString(); //Random ve Unique bir değer olmalı
        string NHSecurityData = strProvisionPassword + _strTerminalID;
        string strinstallmentnumber1 = "2"; // 2 farklı taksit seçimi örneğimize ekledik 1. 2 taksit olsun
        string strinstallmentnumber2 = "5"; // 2 farklı taksit seçimi 2. 5 olsun
        string SecurityData = GetSHA1(strProvisionPassword + _strTerminalID).ToUpper();

        string NHHashData = strTerminalID + strOrderID + strAmount + strSuccessURL + strErrorURL + strType + strInstallmentCount + strStoreKey + SecurityData;

        string HashData = GetSHA1(strTerminalID + strOrderID + strAmount + strSuccessURL + strErrorURL + strType + strInstallmentCount + strStoreKey + SecurityData).ToUpper();



        divPost.InnerHtml = "<form id=\"form2\" name=\"form2\" method=\"post\" action=\"" + "https://sanalposprov.garanti.com.tr/servlet/gt3dengine" + "\">";
        divPost.InnerHtml += "<div>";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"secure3dsecuritylevel\"  id=\"secure3dsecuritylevel\"  Value=\"" + srtsecure3dsecuritylevel + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"mode\"  id=\"mode\"  Value=\"" + strMode + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"apiversion\"  id=\"apiversion\"  Value=\"" + strApiVersion + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"terminalprovuserid\"  id=\"terminalprovuserid\"  Value=\"" + strTerminalProvUserID + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"terminaluserid\"  id=\"terminaluserid\"  Value=\"" + strTerminalUserID + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"terminalmerchantid\"  id=\"terminalmerchantid\"  Value=\"" + strTerminalMerchantID + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"txntype\"  id=\"txntype\"  Value=\"" + strType + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"txnamount\"  id=\"txnamount\"  Value=\"" + strAmount + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"txncurrencycode\"  id=\"txncurrencycode\"  Value=\"" + strCurrencyCode + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"txninstallmentcount\"  id=\"txninstallmentcount\"  Value=\"" + strInstallmentCount + "\" />";

        divPost.InnerHtml += "<input type=\"hidden\" name=\"customeremailaddress\"  id=\"customeremailaddress\"  Value=\"" + strCustomeremailaddress + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"customeripaddress\"  id=\"customeripaddress\"  Value=\"" + strCustomeripaddress + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"orderid\"  id=\"orderid\"  Value=\"" + strOrderID + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"terminalid\"  id=\"terminalid\"  Value=\"" + strTerminalID + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"successurl\"  id=\"successurl\"  Value=\"" + strSuccessURL + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"errorurl\"  id=\"errorurl\"  Value=\"" + strErrorURL + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"companyname\"  id=\"companyname\"  Value=\"" + strCompanyName + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"lang\"  id=\"lang\"  Value=\"" + strlang + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"secure3dhash\"  id=\"secure3dhash\"  Value=\"" + HashData + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"txntimestamp\"  id=\"txntimestamp\"  Value=\"" + strtimestamp + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"refreshtime\"  id=\"refreshtime\"  Value=\"" + strRefreshTime + "\" />";

        divPost.InnerHtml += "<input type=\"hidden\" name=\"bnsuseflag\"  id=\"bnsuseflag\"  Value=\"N\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"fbbuseflag\"  id=\"fbbuseflag\"  Value=\"N\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"chequeuseflag\"  id=\"chequeuseflag\" Value=\"N\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"txnsubtype\"  id=\"txnsubtype\"  Value=\"" + strtxnsubtype + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"garantipay\"  id=\"garantipay\"   Value=\"Y\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"totallinstallmentcount\"  id=\"totallinstallmentcount\"  Value=\"2\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"installmentnumber1\"  id=\"installmentnumber1\"  Value=\"" + strinstallmentnumber1 + "\" />";  //1. taksit seçimi 2 taksit örnek
        divPost.InnerHtml += "<input type=\"hidden\" name=\"installmentamount1\"  id=\"installmentamount1\"  Value=\"" + strinstallmentamount1 + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"installmentratewithreward1\"  id=\"installmentratewithreward1\"   Value=\"1000\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"installmentnumber2\"  id=\"installmentnumber2\"  Value=\"" + strinstallmentnumber2 + "\" />";   //2. taksit seçimi 5 taksit örnek
        divPost.InnerHtml += "<input type=\"hidden\" name=\"installmentamount2\"  id=\"installmentamount2\"  Value=\"" + strinstallmentamount2 + "\" />";
        divPost.InnerHtml += "<input type=\"hidden\" name=\"installmentratewithreward2\"  id=\"installmentratewithreward2\"   Value=\"2000\" />";
        divPost.InnerHtml += "</div></form><script type=\"text/javascript\">form2.submit();</script>";
        /*
                  
//installmentratewithreward1" value="1000" - 1.taksit alanı (komisyon oranı-bonus kullanılırsa %10)

         */



        }
               catch (Exception Ex)
        {
       string error = Ex.Message;
        }

    }



    public string GetSHA1(string SHA1Data)
    {
        SHA1 sha = new SHA1CryptoServiceProvider();
        string HashedPassword = SHA1Data;
        byte[] hashbytes = Encoding.GetEncoding("ISO-8859-9").GetBytes(HashedPassword);
        byte[] inputbytes = sha.ComputeHash(hashbytes);
        return GetHexaDecimal(inputbytes);
    }

    public string GetHexaDecimal(byte[] bytes)
    {
        StringBuilder s = new StringBuilder();
        int length = bytes.Length;
        for (int n = 0; n <= length - 1; n++)
        {
            s.Append(String.Format("{0,2:x}", bytes[n]).Replace(" ", "0"));
        }
        return s.ToString();
    }



    #region "Kod Oluştur"
    /// <summary>
    /// Metinde türkçe karakterleri temizliyoruz ve boşlukları  değiştiriyoruz.
    /// </summary>
    /// <param name="Text"></param>
    /// <returns></returns>
    public static string KodOlustur(string Text)
    {
        try
        {
            string strReturn = Text.Trim();

            strReturn = strReturn.Replace("ğ", "g");
            strReturn = strReturn.Replace("Ğ", "G");
            strReturn = strReturn.Replace("ü", "u");
            strReturn = strReturn.Replace("Ü", "U");
            strReturn = strReturn.Replace("ş", "s");
            strReturn = strReturn.Replace("Ş", "S");
            strReturn = strReturn.Replace("ı", "i");
            strReturn = strReturn.Replace("İ", "I");
            strReturn = strReturn.Replace("ö", "o");
            strReturn = strReturn.Replace("Ö", "O");
            strReturn = strReturn.Replace("ç", "c");
            strReturn = strReturn.Replace("Ç", "C");
            strReturn = strReturn.Replace("-", "+");
            strReturn = strReturn.Replace(" ", "+");
            strReturn = strReturn.Trim();
            strReturn = new System.Text.RegularExpressions.Regex("[^a-zA-Z0-9+]").Replace(strReturn, "");
            strReturn = strReturn.Trim();
            strReturn = strReturn.Replace("+", "_");
            return strReturn;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion

   
}
