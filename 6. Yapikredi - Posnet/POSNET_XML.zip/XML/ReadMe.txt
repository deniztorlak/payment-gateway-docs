Posnet XML Service Samples

This directory includes source code for Posnet XML Service Samples.