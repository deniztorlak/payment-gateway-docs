package com.ykb.posnet.merchant.xml;

/**
 * Insert the type's description here.
 * Creation date: (06.08.2003 10:22:00)
 * @author: Administrator
 */
public class MerchData {
	public java.lang.String mid;
	public java.lang.String tid;
	public java.lang.String XID;
	public java.lang.String Amount;
	public java.lang.String CurrencyCode;
	public java.lang.String InstNumber;
	public java.lang.String point;
	public java.lang.String pointTL;
	public java.lang.String hostName;
	public java.lang.String hostIP;
	public java.lang.String port;
	public java.lang.String errorCode;
	public java.lang.String errorMessage;
	public java.lang.String mdStatus;
	public java.lang.String mdErrorMsg;
	public java.lang.String txstatus;
	public java.lang.String tranDate;
	
/**
 * MerchData constructor comment.
 */
public MerchData() {
	super();
	mid = "";
	tid = "";
	XID = "";
	Amount = "" ;
	InstNumber = "";
	hostName = "";
	port = "";
	errorCode = "";
 	errorMessage = "";
	mdStatus = "";
	mdErrorMsg = "";
	txstatus = "";
	tranDate = "";
}
}
