﻿
Partial Class merchant_islem_sonu
    Inherits System.Web.UI.Page

End Class
